import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  // 'base' define o caminho base dos assets. 
  // './' garante que funcione em qualquer subdiretório (como no GitHub Pages)
  // Se o seu repo for https://usuario.github.io/acai-tati/, isso garante que carregue.
  base: './', 
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    sourcemap: false
  }
});